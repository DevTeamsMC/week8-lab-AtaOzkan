
namespace Exp6
{
    public partial class Form1 : Form
    {
        public string zorluk = "Kolay";
        public int sure = 30;
        public string tasarim = "Klasik";


        public Form1()
        {

            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (comboBoxKategori.SelectedItem == null)
            {
                MessageBox.Show("L�tfen bir kategori se�in.");
                return;
            }

            string secilenKategori = comboBoxKategori.SelectedItem.ToString();
            Form2 gameForm = new Form2(secilenKategori, zorluk, sure, tasarim);
            gameForm.FormClosed += (s, args) => this.Show(); 
            gameForm.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBoxKategori.Items.AddRange(new string[] { "Hayvanlar", "�lke" });
            comboBoxKategori.SelectedIndex = 0; 
        }



        private void btnSettings_Click(object sender, EventArgs e)
        {
            Form3 settingsForm = new Form3(zorluk, sure, tasarim);
            if (settingsForm.ShowDialog() == DialogResult.OK)
            {
                zorluk = settingsForm.Zorluk;
                sure = settingsForm.Sure;
                tasarim = settingsForm.Tasarim;
            }
        }
    }
}
