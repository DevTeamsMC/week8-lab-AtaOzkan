﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exp6;


public partial class Form3 : Form
{
    public string Zorluk { get; private set; }
    public int Sure { get; private set; }
    public string Tasarim { get; private set; }

    public Form3(string mevcutZorluk, int mevcutSure, string mevcutTasarim)
    {
        InitializeComponent();

        comboBoxZorluk.Items.AddRange(new string[] { "Kolay", "Orta", "Zor" });
        comboBoxZorluk.SelectedItem = mevcutZorluk;

        numericUpDownSure.Minimum = 10;
        numericUpDownSure.Maximum = 300;
        numericUpDownSure.Value = mevcutSure;

        comboBoxTasarim.Items.AddRange(new string[] { "Çiçek", "Klasik" });
        comboBoxTasarim.SelectedItem = mevcutTasarim;
    }


    private void kaydet_Click(object sender, EventArgs e)
    {
        Zorluk = comboBoxZorluk.SelectedItem.ToString();
        Sure = (int)numericUpDownSure.Value;
        Tasarim = comboBoxTasarim.SelectedItem.ToString();

        this.DialogResult = DialogResult.OK;
        this.Close();


        this.Hide();
    }



}
