﻿namespace Exp6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtGuess = new TextBox();
            lblWord = new Label();
            lblHint = new Label();
            lblWrongGuesses = new Label();
            lblScore = new Label();
            btnGuess = new Button();
            btnEndGame = new Button();
            pictureBoxHangman = new PictureBox();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            lblSettings = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBoxHangman).BeginInit();
            SuspendLayout();
            // 
            // txtGuess
            // 
            txtGuess.Location = new Point(27, 523);
            txtGuess.Name = "txtGuess";
            txtGuess.Size = new Size(81, 27);
            txtGuess.TabIndex = 0;
            txtGuess.KeyPress += txtGuess_KeyPress;
            // 
            // lblWord
            // 
            lblWord.AutoSize = true;
            lblWord.Font = new Font("Showcard Gothic", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblWord.Location = new Point(182, 96);
            lblWord.Name = "lblWord";
            lblWord.Size = new Size(144, 46);
            lblWord.TabIndex = 1;
            lblWord.Text = "label1";
            // 
            // lblHint
            // 
            lblHint.AutoSize = true;
            lblHint.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHint.Location = new Point(138, 177);
            lblHint.Name = "lblHint";
            lblHint.Size = new Size(71, 28);
            lblHint.TabIndex = 2;
            lblHint.Text = "label2";
            // 
            // lblWrongGuesses
            // 
            lblWrongGuesses.AutoSize = true;
            lblWrongGuesses.Font = new Font("Segoe Script", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblWrongGuesses.Location = new Point(27, 325);
            lblWrongGuesses.Name = "lblWrongGuesses";
            lblWrongGuesses.Size = new Size(110, 44);
            lblWrongGuesses.TabIndex = 4;
            lblWrongGuesses.Text = "label4";
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Font = new Font("Segoe Script", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblScore.Location = new Point(27, 453);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(110, 44);
            lblScore.TabIndex = 5;
            lblScore.Text = "label5";
            // 
            // btnGuess
            // 
            btnGuess.BackColor = Color.Lime;
            btnGuess.Location = new Point(229, 523);
            btnGuess.Name = "btnGuess";
            btnGuess.Size = new Size(105, 28);
            btnGuess.TabIndex = 6;
            btnGuess.Text = "Tahmin Et";
            btnGuess.UseVisualStyleBackColor = false;
            btnGuess.Click += btnGuess_Click;
            // 
            // btnEndGame
            // 
            btnEndGame.BackColor = Color.Yellow;
            btnEndGame.Location = new Point(445, 520);
            btnEndGame.Name = "btnEndGame";
            btnEndGame.Size = new Size(94, 29);
            btnEndGame.TabIndex = 7;
            btnEndGame.Text = "Oyunu Bitir";
            btnEndGame.UseVisualStyleBackColor = false;
            btnEndGame.Click += btnEndGame_Click;
            // 
            // pictureBoxHangman
            // 
            pictureBoxHangman.Location = new Point(651, 96);
            pictureBoxHangman.Name = "pictureBoxHangman";
            pictureBoxHangman.Size = new Size(398, 464);
            pictureBoxHangman.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxHangman.TabIndex = 8;
            pictureBoxHangman.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Showcard Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(409, 23);
            label1.Name = "label1";
            label1.Size = new Size(220, 50);
            label1.TabIndex = 9;
            label1.Text = "HANGMAN";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // lblSettings
            // 
            lblSettings.AutoSize = true;
            lblSettings.Font = new Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSettings.Location = new Point(651, 56);
            lblSettings.Name = "lblSettings";
            lblSettings.Size = new Size(59, 18);
            lblSettings.TabIndex = 10;
            lblSettings.Text = "label2";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1061, 581);
            Controls.Add(lblSettings);
            Controls.Add(label1);
            Controls.Add(pictureBoxHangman);
            Controls.Add(btnEndGame);
            Controls.Add(btnGuess);
            Controls.Add(lblScore);
            Controls.Add(lblWrongGuesses);
            Controls.Add(lblHint);
            Controls.Add(lblWord);
            Controls.Add(txtGuess);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxHangman).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtGuess;
        private Label lblWord;
        private Label lblHint;
        private Label lblWrongGuesses;
        private Label lblScore;
        private Button btnGuess;
        private Button btnEndGame;
        private PictureBox pictureBoxHangman;
        private Label label1;
        private System.Windows.Forms.Timer timer1;
        private Label lblSettings;
    }
}