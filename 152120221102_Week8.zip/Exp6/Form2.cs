﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Exp6
{
    public partial class Form2 : Form
    {


        private string kategori;
        private string zorluk;
        private int sure;
        private string tasarim;

        string selectedWord;
        string displayWord;
        int wrongGuesses = 0;
        int score = 100;
        int timeLeft;
        List<char> wrongLetters = new List<char>();

        public class Soru
        {
            public string Kelime { get; set; }
            public string Ipuco { get; set; }
            public string Zorluk { get; set; }
        }

        public List<Soru> TumSorular = new List<Soru>();

        public Form2(string kategori, string zorluk, int sure, string tasarim)
        {
            InitializeComponent();
            this.kategori = kategori;
            this.zorluk = zorluk;
            this.sure = sure;
            this.tasarim = tasarim;
            lblSettings.Text = $"Kategori: {kategori} - Seviye: {zorluk}";
            timeLeft = sure;

            SorulariYukle();
            StartGame();
            timer1.Start();
        }

        public void SorulariYukle()
        {
            List<string> dosyaSatirlari = new List<string>();

            if (kategori == "Hayvanlar")
            {
                dosyaSatirlari = File.ReadAllLines(Path.Combine(Application.StartupPath, "Hayvanlar.txt")).ToList();
            }
            else if (kategori == "Ülke")
            {
                string dosyaYolu = Path.Combine(Application.StartupPath, "Ülke.txt");
                if (!File.Exists(dosyaYolu))
                {
                    MessageBox.Show($"Dosya bulunamadı: {dosyaYolu}");
                    return;
                }
                dosyaSatirlari = File.ReadAllLines(dosyaYolu).ToList();
            }

            if (dosyaSatirlari.Any())
            {
                foreach (var satir in dosyaSatirlari)
                {
                    string[] parcalar = satir.Split(',');
                    if (parcalar.Length == 3)  
                    {
                        Soru s = new Soru
                        {
                            Kelime = parcalar[0].Trim().ToLower(),
                            Ipuco = parcalar[1].Trim(),
                            Zorluk = parcalar[2].Trim().ToLower()
                        };

                       
                        if (!string.IsNullOrEmpty(s.Zorluk) && !string.IsNullOrEmpty(zorluk) && s.Zorluk.ToLower() == zorluk.ToLower())
                        {
                            TumSorular.Add(s);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Kategoriye ait dosya içeriği boş veya okunamadı!");
            }
        }



        public void StartGame()
        {
            timer1.Interval = 1000; 
            timer1.Start(); 

            Random rnd = new Random();
            var filtrelenmis = TumSorular.Where(s => s.Zorluk.ToLower() == zorluk.ToLower()).ToList();

            if (filtrelenmis.Count >= 1)
            {
                var secilenSoru = filtrelenmis[rnd.Next(filtrelenmis.Count)];
                selectedWord = secilenSoru.Kelime;
                lblHint.Text = "Hint: " + secilenSoru.Ipuco;

                displayWord = new string('_', selectedWord.Length);
                lblWord.Text = string.Join(" ", displayWord.ToCharArray());

                lblWrongGuesses.Text = "Wrong Letters: ";
                lblScore.Text = $"Score: {score}  |  Time left: {timeLeft}s";
            }
            else
            {
                MessageBox.Show($"Seçilen zorlukta yeterli soru yok. Zorluk: {zorluk}, Soru Sayısı: {TumSorular.Count}");
                this.Close();
            }
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtGuess.Text)) return;

            char guess;
            if (char.TryParse(txtGuess.Text.ToLower(), out guess))
            {
                if (selectedWord.Contains(guess))
                {
                    var updatedDisplay = displayWord.ToCharArray();
                    for (int i = 0; i < selectedWord.Length; i++)
                    {
                        if (selectedWord[i] == guess)
                        {
                            updatedDisplay[i] = guess;
                        }
                    }
                    displayWord = new string(updatedDisplay);
                    lblWord.Text = string.Join(" ", displayWord.ToCharArray());

                    if (!displayWord.Contains('_'))
                    {
                        timer1.Stop();
                        MessageBox.Show("You won!");
                        this.BackColor = Color.Green;
                        DisableInputs();
                    }
                }
                else
                {
                    if (!wrongLetters.Contains(guess))
                    {
                        wrongGuesses++;
                        score -= 10;
                        wrongLetters.Add(guess);
                        lblWrongGuesses.Text = $"Wrong Letters: {string.Join(", ", wrongLetters)}";

                        
                        string resimKlasoru = tasarim == "Klasik" ? "images1" : "images2";
                        string resimYolu = Path.Combine(Application.StartupPath, resimKlasoru, $"hangman{wrongGuesses}.jpg");
                        if (File.Exists(resimYolu))
                        {
                            pictureBoxHangman.Image = Image.FromFile(resimYolu);
                        }
                        else
                        {
                            MessageBox.Show($"Resim bulunamadı: {resimYolu}");
                        }

                        if (wrongGuesses == 9)
                        {
                            timer1.Stop();
                            MessageBox.Show($"You lost! The word was '{selectedWord}'");
                            this.BackColor = Color.Red;
                            DisableInputs();
                        }
                    }
                }

                lblScore.Text = $"Score: {score}  |  Time left: {timeLeft}s";
            }

            txtGuess.Clear();
            txtGuess.Focus();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeLeft--;

            lblScore.Text = $"Score: {score}  |  Time left: {timeLeft}s";

            if (timeLeft <= 0)
            {
                timer1.Stop();
                MessageBox.Show("Süre doldu! Kaybettiniz!");
                this.BackColor = Color.Red;
                DisableInputs();
            }
        }

        private void btnEndGame_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to end the game?", "End Game", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void DisableInputs()
        {
            btnGuess.Enabled = false;
            txtGuess.Enabled = false;
        }

        private void txtGuess_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }

            if (txtGuess.Text.Length >= 1 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
