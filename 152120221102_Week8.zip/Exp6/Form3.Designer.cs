﻿namespace Exp6
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            comboBoxZorluk = new ComboBox();
            numericUpDownSure = new NumericUpDown();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            comboBoxTasarim = new ComboBox();
            label4 = new Label();
            kaydet = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDownSure).BeginInit();
            SuspendLayout();
            // 
            // comboBoxZorluk
            // 
            comboBoxZorluk.FormattingEnabled = true;
            comboBoxZorluk.Location = new Point(53, 143);
            comboBoxZorluk.Margin = new Padding(3, 4, 3, 4);
            comboBoxZorluk.Name = "comboBoxZorluk";
            comboBoxZorluk.Size = new Size(105, 28);
            comboBoxZorluk.TabIndex = 0;
            // 
            // numericUpDownSure
            // 
            numericUpDownSure.Location = new Point(53, 239);
            numericUpDownSure.Margin = new Padding(3, 4, 3, 4);
            numericUpDownSure.Name = "numericUpDownSure";
            numericUpDownSure.Size = new Size(105, 27);
            numericUpDownSure.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Location = new Point(53, 119);
            label1.Name = "label1";
            label1.Size = new Size(51, 20);
            label1.TabIndex = 2;
            label1.Text = "Zorluk";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Location = new Point(53, 215);
            label2.Name = "label2";
            label2.Size = new Size(38, 20);
            label2.TabIndex = 3;
            label2.Text = "Süre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Showcard Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(53, 38);
            label3.Name = "label3";
            label3.Size = new Size(212, 50);
            label3.TabIndex = 10;
            label3.Text = "SETTINGS";
            // 
            // comboBoxTasarim
            // 
            comboBoxTasarim.FormattingEnabled = true;
            comboBoxTasarim.Location = new Point(53, 337);
            comboBoxTasarim.Margin = new Padding(3, 4, 3, 4);
            comboBoxTasarim.Name = "comboBoxTasarim";
            comboBoxTasarim.Size = new Size(105, 28);
            comboBoxTasarim.TabIndex = 11;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Location = new Point(53, 313);
            label4.Name = "label4";
            label4.Size = new Size(59, 20);
            label4.TabIndex = 12;
            label4.Text = "Tasarım";
            // 
            // kaydet
            // 
            kaydet.Location = new Point(53, 392);
            kaydet.Margin = new Padding(3, 4, 3, 4);
            kaydet.Name = "kaydet";
            kaydet.Size = new Size(86, 31);
            kaydet.TabIndex = 14;
            kaydet.Text = "Kaydet";
            kaydet.UseVisualStyleBackColor = true;
            kaydet.Click += kaydet_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(316, 456);
            Controls.Add(kaydet);
            Controls.Add(label4);
            Controls.Add(comboBoxTasarim);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(numericUpDownSure);
            Controls.Add(comboBoxZorluk);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form3";
            Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)numericUpDownSure).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBoxZorluk;
        private NumericUpDown numericUpDownSure;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox comboBoxTasarim;
        private Label label4;
        private Button kaydet;
    }
}