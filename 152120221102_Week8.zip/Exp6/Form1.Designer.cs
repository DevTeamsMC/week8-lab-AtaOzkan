﻿namespace Exp6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnStart = new Button();
            label1 = new Label();
            comboBoxKategori = new ComboBox();
            btnSettings = new Button();
            SuspendLayout();
            // 
            // btnStart
            // 
            btnStart.BackColor = SystemColors.Control;
            btnStart.Font = new Font("Showcard Gothic", 28.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnStart.ForeColor = Color.IndianRed;
            btnStart.Location = new Point(268, 342);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(256, 67);
            btnStart.TabIndex = 0;
            btnStart.Text = "BAŞLA";
            btnStart.UseVisualStyleBackColor = false;
            btnStart.Click += btnStart_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Showcard Gothic", 48F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(94, 100);
            label1.Name = "label1";
            label1.Size = new Size(659, 98);
            label1.TabIndex = 1;
            label1.Text = "HANGMAN GAME";
            // 
            // comboBoxKategori
            // 
            comboBoxKategori.FormattingEnabled = true;
            comboBoxKategori.Location = new Point(600, 16);
            comboBoxKategori.Margin = new Padding(3, 4, 3, 4);
            comboBoxKategori.Name = "comboBoxKategori";
            comboBoxKategori.Size = new Size(117, 28);
            comboBoxKategori.TabIndex = 2;
            // 
            // btnSettings
            // 
            btnSettings.Font = new Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSettings.ForeColor = Color.IndianRed;
            btnSettings.Location = new Point(723, 16);
            btnSettings.Margin = new Padding(3, 4, 3, 4);
            btnSettings.Name = "btnSettings";
            btnSettings.Size = new Size(86, 31);
            btnSettings.TabIndex = 3;
            btnSettings.Text = "Ayarlar";
            btnSettings.UseVisualStyleBackColor = true;
            btnSettings.Click += btnSettings_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.cover2;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(823, 524);
            Controls.Add(btnSettings);
            Controls.Add(comboBoxKategori);
            Controls.Add(label1);
            Controls.Add(btnStart);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnStart;
        private Label label1;
        private ComboBox comboBoxKategori;
        private Button btnSettings;
    }
}
